# EasyPrompt
Simple module for taking and parsing commands from the user in a prompt-style interface

### Installation

    pip install easyprompt
